// Taş, kağıt, makas oyunu icin kullanici secenekleri
let secenekler = ["taş", "kağıt", "makas"];

// Kullanıcıya seçimini yaptıralım
let kullaniciSecimi = prompt("Taş, kağıt ya da makas seçin:");

// Kullanıcının seçiminin geçerli olup olmadığını kontrol edelim
if (secenekler.indexOf(kullaniciSecimi) !== -1) {
    // Bilgisayarın seçimini rastgele belirleyelim
    let bilgisayarSecimi = secenekler[Math.floor(Math.random() * secenekler.length)];

    // Kullanıcının seçimiyle bilgisayarın seçimini karşılaştıralım
    if ((kullaniciSecimi === "taş" && bilgisayarSecimi === "makas") ||
        (kullaniciSecimi === "kağıt" && bilgisayarSecimi === "taş") ||
        (kullaniciSecimi === "makas" && bilgisayarSecimi === "kağıt")) {
        alert("Kazandınız! Bilgisayar " + bilgisayarSecimi + " seçti.");
    } else if (kullaniciSecimi === bilgisayarSecimi) {
        alert("Berabere! Bilgisayar da " + bilgisayarSecimi + " seçti.");
    } else {
        alert("Kaybettiniz! Bilgisayar " + bilgisayarSecimi + " seçti.");
    }
} else {
    alert("Geçersiz seçim yaptınız. Lütfen taş, kağıt veya makas seçin.");
}